from cybervpn import *
import datetime as DT

@bot.on(events.CallbackQuery(data=b'addsaldo'))
async def saldo_handler(event):
    user_id = str(event.sender_id)

    async def get_input(conv, prompt):
        await event.respond(prompt)
        input_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=user_id))
        return input_msg.raw_text

    async with bot.conversation(event.chat_id) as user_conv:
        user = await get_input(user_conv, '**Masukkan id telegram user:**')

    async with bot.conversation(event.chat_id) as saldo_conv:
        saldo = await get_input(saldo_conv, '**Masukkan jumlah saldo:**')

    # Tambahkan saldo sebelum mendapatkan level
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            tambah_saldo(user, saldo)
            today = DT.date.today()
            later = today + DT.timedelta(days=int(0))
            msg = f"""
**━━━━━━━━━━━━━━━━━**
**⟨ Success add saldo member ⟩**
**━━━━━━━━━━━━━━━━━**
**» Your ID:** `{user_id}`
**» ID user:** `{user}`
**» Balance:** `IDR.{saldo}`
**» status:** `success✅`
**━━━━━━━━━━━━━━━━**
**» Tanggal topup:** `{later}`
**» 🤖 @Candravpnz**
**━━━━━━━━━━━━━━━━**
"""
            inline = [
                [Button.url("[ Contact ]", "t.me/Candravpnz"),
                 Button.url("[ Channel ]", "t.me/Candravpnz")]
            ]
            await event.respond(msg, buttons=inline)
        else:
            await event.answer(f'Akses Ditolak.!!', alert=True)

    except Exception as e:
        print(f'Error: {e}')

